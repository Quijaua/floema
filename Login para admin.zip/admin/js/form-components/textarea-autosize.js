// Forms Textarea Autosize

$(document).ready(() => {
  $("textarea.autosize-input").textareaAutoSize();
});
