// Forms Input Mask

$(document).ready(() => {
  $(".input-mask-trigger").inputmask();
});
