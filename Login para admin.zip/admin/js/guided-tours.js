// Guided Tours

$(document).ready(() => {
  $(".start-tour").click(function () {
    introJs().start();
  });
});
