<h1>404</h1>
<p>Página não encontrada!</p>
<a href="<?php echo INCLUDE_PATH_ADMIN; ?>">Voltar</a>